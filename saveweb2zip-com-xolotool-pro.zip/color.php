<html><head></head><body>:root {
    --clr-main: #8CBE06;
}

.feature-box .content {
    box-shadow: inset 0 0px 66px #8CBE0647;
}

.invest-plan-top::before {
    box-shadow: inset 0 0px 66px #8CBE06d4;
}

.invest-plan::before {
    box-shadow: inset 0 0px 66px #8CBE063b;
}

.invest-plan-shape::after {
    background-color: #8CBE0633;
}

.invest-plan:hover .invest-plan-shape::after {
    background-color: #8CBE06;
}

.work-box {
    box-shadow: inset 0 0px 20px #8CBE06c4;
}

.work-box .icon {
    box-shadow: inset 0 0px 20px #8CBE06c4;
}

.cmn-table.style-separate tbody tr {
    box-shadow: inset 0 0px 8px #8CBE064d;
}

.testimonial-box .content {
    box-shadow: inset 0 0px 20px #8CBE06c4;
}

.referral-box::before {
    box-shadow: inset 0 0px 20px #8CBE06c4;
}

.referral-box-step {
    box-shadow: inset 0 0px 6px #8CBE069e;
}

.choose-wrapper .choose-wrapper-thumb .thumb-inner {
    box-shadow: 0 5px 25px #8CBE0659;
}

.choose-wrapper-inner .choose-item .icon {
    box-shadow: inset 0px 5px 9px #8CBE064d;
}

.pricing-item .icon {
    box-shadow: inset 0 0 10px #8CBE0659;
}

.pricing-item .plan-name span {
    background-color: #8CBE0626;
}

.referral-item .rate {
    box-shadow: 0 0 0 8px #8CBE0640;
}</body></html>